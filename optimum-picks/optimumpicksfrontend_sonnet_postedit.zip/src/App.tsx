// src/App.tsx
import React, { useState } from 'react';
import { Box, AppBar, Toolbar, Typography, Button, IconButton, Paper, InputBase, Chip, Switch, FormControlLabel } from '@mui/material';
import SearchIcon from '@mui/icons-material/Search';
import RefreshIcon from '@mui/icons-material/Refresh';
import PersonIcon from '@mui/icons-material/Person';
import BarChartIcon from '@mui/icons-material/BarChart';
import LightModeIcon from '@mui/icons-material/LightMode';
import DarkModeIcon from '@mui/icons-material/DarkMode';
import BettingTable from './components/BettingTable';
import OptimumTable from './components/OptimumTable';
import Dashboard from './components/Dashboard';
import { mockData, optimumData } from './data/mockData';
import './App.css';

function App() {
  const [activeTab, setActiveTab] = useState<'ev' | 'arb' | 'opt' | 'analytics'>('ev');
  const [isLightMode, setIsLightMode] = useState(false);

  // Theme styles based on mode (only for Plus EV page)
  const getThemeStyles = () => {
    if (activeTab === 'ev' && isLightMode) {
      return {
        background: 'linear-gradient(135deg, #f5f7fa 0%, #c3cfe2 100%)',
        color: '#333',
        appBarBg: 'rgba(255, 255, 255, 0.9)',
        appBarColor: '#333',
        borderColor: 'rgba(0, 0, 0, 0.1)',
        searchBg: 'rgba(255, 255, 255, 0.8)',
        searchColor: '#333',
        chipBg: 'rgba(0, 0, 0, 0.1)',
        chipColor: '#333',
        buttonHover: 'rgba(0, 0, 0, 0.05)',
        iconColor: '#666',
      };
    }
    // Default dark theme
    return {
      background: 'transparent',
      color: 'rgba(255, 255, 255, 0.9)',
      appBarBg: 'transparent',
      appBarColor: 'rgba(255, 255, 255, 0.9)',
      borderColor: 'rgba(255, 255, 255, 0.1)',
      searchBg: 'rgba(255, 255, 255, 0.05)',
      searchColor: 'rgba(255, 255, 255, 0.9)',
      chipBg: 'rgba(255, 255, 255, 0.1)',
      chipColor: 'rgba(255, 255, 255, 0.9)',
      buttonHover: 'rgba(255, 255, 255, 0.05)',
      iconColor: 'rgba(255, 255, 255, 0.7)',
    };
  };

  const theme = getThemeStyles();

  return (
    <Box sx={{ 
      display: 'flex', 
      flexDirection: 'column', 
      height: '100vh', 
      position: 'relative', 
      zIndex: 1,
      background: theme.background,
      color: theme.color,
      transition: 'all 0.3s ease-in-out',
    }}>
      <AppBar position="static" sx={{ 
        background: theme.appBarBg, 
        boxShadow: 'none', 
        borderBottom: `1px solid ${theme.borderColor}`,
        backdropFilter: activeTab === 'ev' && isLightMode ? 'blur(10px)' : 'none',
        transition: 'all 0.3s ease-in-out',
      }}>
        <Toolbar>
          <Typography variant="h6" component="div" sx={{ 
            flexGrow: 0, 
            fontWeight: 300, 
            letterSpacing: '1px',
            color: theme.appBarColor, 
            mr: 4,
            transition: 'color 0.3s ease-in-out',
          }}>
            OPTIMUM PICKS
          </Typography>
          
          <Button 
            onClick={() => setActiveTab('ev')}
            sx={{ 
              color: activeTab === 'ev' ? (isLightMode ? '#1976d2' : 'rgba(255,255,255,0.9)') : (isLightMode && activeTab === 'ev' ? '#666' : 'rgba(255,255,255,0.5)'), 
              textTransform: 'none', 
              mr: 2,
              fontWeight: activeTab === 'ev' ? 500 : 300,
              letterSpacing: '0.5px',
              fontSize: '0.9rem',
              transition: 'all 0.3s ease-in-out',
              '&:hover': {
                backgroundColor: theme.buttonHover
              }
            }}
          >
            Plus EV
          </Button>
          
          <Button 
            onClick={() => setActiveTab('arb')}
            sx={{ 
              color: activeTab === 'arb' ? 'rgba(255,255,255,0.9)' : 'rgba(255,255,255,0.5)', 
              textTransform: 'none',
              fontWeight: 300,
              letterSpacing: '0.5px',
              fontSize: '0.9rem',
              marginRight: 2,
              '&:hover': {
                backgroundColor: 'rgba(255,255,255,0.05)'
              }
            }}
          >
            Arbitrage
          </Button>
          
          <Button 
            onClick={() => setActiveTab('opt')}
            sx={{ 
              color: activeTab === 'opt' ? 'rgba(255,255,255,0.9)' : 'rgba(255,255,255,0.5)', 
              textTransform: 'none',
              fontWeight: 300,
              letterSpacing: '0.5px',
              fontSize: '0.9rem',
              marginRight: 2,
              '&:hover': {
                backgroundColor: 'rgba(255,255,255,0.05)'
              }
            }}
          >
            Optimums
          </Button>
          
          <Button 
            onClick={() => setActiveTab('analytics')}
            sx={{ 
              color: activeTab === 'analytics' ? '#00FFAB' : 'rgba(255,255,255,0.5)', 
              textTransform: 'none',
              fontWeight: activeTab === 'analytics' ? 500 : 300,
              letterSpacing: '0.5px',
              fontSize: '0.9rem',
              bgcolor: activeTab === 'analytics' ? 'rgba(0, 255, 171, 0.1)' : 'transparent',
              border: activeTab === 'analytics' ? '1px solid rgba(0, 255, 171, 0.3)' : 'none',
              borderRadius: '8px',
              px: 2,
              '&:hover': {
                backgroundColor: 'rgba(0, 255, 171, 0.05)'
              }
            }}
            startIcon={<BarChartIcon />}
          >
            Analytics
          </Button>
          
          <Box sx={{ flexGrow: 1 }} />
          
          {/* Theme Toggle - Only show on Plus EV page */}
          {activeTab === 'ev' && (
            <FormControlLabel
              control={
                <Switch
                  checked={isLightMode}
                  onChange={(e) => setIsLightMode(e.target.checked)}
                  sx={{
                    '& .MuiSwitch-switchBase.Mui-checked': {
                      color: '#1976d2',
                    },
                    '& .MuiSwitch-switchBase.Mui-checked + .MuiSwitch-track': {
                      backgroundColor: '#1976d2',
                    },
                  }}
                />
              }
              label={
                <Box sx={{ display: 'flex', alignItems: 'center', gap: 0.5 }}>
                  {isLightMode ? <LightModeIcon sx={{ fontSize: 18 }} /> : <DarkModeIcon sx={{ fontSize: 18 }} />}
                  <Typography variant="body2" sx={{ fontSize: '0.8rem' }}>
                    {isLightMode ? 'Light' : 'Dark'}
                  </Typography>
                </Box>
              }
              sx={{
                mr: 2,
                '& .MuiFormControlLabel-label': {
                  color: theme.appBarColor,
                  transition: 'color 0.3s ease-in-out',
                },
              }}
            />
          )}
          
          <IconButton sx={{ color: theme.iconColor, transition: 'color 0.3s ease-in-out' }}>
            <PersonIcon />
          </IconButton>
        </Toolbar>
      </AppBar>
      
      <Box sx={{ 
        width: '100%',
        px: 2, 
        py: 2, 
        flex: 1, 
        display: 'flex', 
        flexDirection: 'column',
        position: 'relative',
        zIndex: 2,
        maxWidth: '100vw',
      }}>
        {activeTab !== 'analytics' && (
          <Box sx={{ display: 'flex', alignItems: 'center', mb: 2 }}>
            <Typography variant="h4" component="h1" sx={{ 
              fontWeight: 200, 
              letterSpacing: '1px',
              color: theme.color, 
              flexGrow: 1,
              transition: 'color 0.3s ease-in-out',
            }}>
              {activeTab === 'ev' 
                ? 'Positive Expected Value (EV) Bets' 
                : activeTab === 'arb' 
                  ? 'Arbitrage Opportunities' 
                  : 'Optimum Prediction Differences'
              }
            </Typography>
          
          <Chip 
            label="Pre-Match" 
            sx={{ 
              bgcolor: theme.chipBg, 
              color: theme.chipColor, 
              fontWeight: 300,
              letterSpacing: '0.5px',
              mr: 1,
              height: 30,
              transition: 'all 0.3s ease-in-out',
              '&:hover': {
                bgcolor: activeTab === 'ev' && isLightMode ? 'rgba(0, 0, 0, 0.15)' : 'rgba(255,255,255,0.15)'
              }
            }} 
          />
          
          <Chip 
            label="Live" 
            sx={{ 
              bgcolor: 'transparent', 
              color: activeTab === 'ev' && isLightMode ? '#666' : 'rgba(255,255,255,0.7)', 
              border: `1px solid ${theme.borderColor}`,
              fontWeight: 300,
              letterSpacing: '0.5px',
              mr: 2,
              height: 30,
              transition: 'all 0.3s ease-in-out',
              '&:hover': {
                bgcolor: theme.buttonHover
              }
            }} 
          />
          
          <Paper
            component="form"
            sx={{
              p: '2px 4px',
              display: 'flex',
              alignItems: 'center',
              width: 250,
              bgcolor: theme.searchBg,
              borderRadius: 2,
              height: 36,
              border: `1px solid ${theme.borderColor}`,
              transition: 'all 0.3s ease-in-out',
            }}
          >
            <IconButton sx={{ p: '10px', color: theme.iconColor, transition: 'color 0.3s ease-in-out' }} aria-label="search">
              <SearchIcon />
            </IconButton>
            <InputBase
              sx={{ 
                ml: 1, 
                flex: 1, 
                color: theme.searchColor,
                transition: 'color 0.3s ease-in-out',
                '& ::placeholder': {
                  color: activeTab === 'ev' && isLightMode ? '#999' : 'rgba(255,255,255,0.5)',
                  opacity: 1,
                }
              }}
              placeholder="Search"
              inputProps={{ 'aria-label': 'search' }}
            />
          </Paper>
          
          <IconButton sx={{ 
            ml: 1, 
            color: theme.iconColor, 
            bgcolor: theme.searchBg, 
            transition: 'all 0.3s ease-in-out',
            '&:hover': { 
              bgcolor: activeTab === 'ev' && isLightMode ? 'rgba(0, 0, 0, 0.1)' : 'rgba(255,255,255,0.1)' 
            } 
          }}>
            <RefreshIcon />
          </IconButton>
        </Box>
        )}
        
        {activeTab === 'analytics' && (
          // ... existing code ...
        )}
        
        <Box sx={{ flex: 1, display: 'flex', flexDirection: 'column', overflow: 'auto', width: '100%' }}>
          {activeTab === 'ev' && (
            <BettingTable data={mockData} tableType="ev" isLightMode={isLightMode} />
          )}
          
          {activeTab === 'arb' && (
            <BettingTable data={mockData} tableType="arb" />
          )}
          
          {activeTab === 'opt' && (
            <OptimumTable data={optimumData} />
          )}
          
          {activeTab === 'analytics' && (
            <Dashboard data={mockData} />
          )}
        </Box>
      </Box>
    </Box>
  );
}

export default App;